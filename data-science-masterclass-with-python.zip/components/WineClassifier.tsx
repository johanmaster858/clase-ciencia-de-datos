
import React, { useState } from 'react';

// Using mean values from the provided statistics as a better default
const initialWineState = {
    'fixed acidity': 8.32,
    'volatile acidity': 0.53,
    'citric acid': 0.27,
    'residual sugar': 2.54,
    'chlorides': 0.087,
    'free sulfur dioxide': 15.87,
    'total sulfur dioxide': 46.47,
    'density': 0.9967,
    'pH': 3.31,
    'sulphates': 0.66,
    'alcohol': 10.42,
};

type WineFeatures = keyof typeof initialWineState;

// Define min, max, and step for each feature based on provided stats
const featureConfig = {
    'fixed acidity': { min: 4.6, max: 15.9, step: 0.1 },
    'volatile acidity': { min: 0.12, max: 1.58, step: 0.01 },
    'citric acid': { min: 0.0, max: 1.0, step: 0.01 },
    'residual sugar': { min: 0.9, max: 15.5, step: 0.1 },
    'chlorides': { min: 0.012, max: 0.611, step: 0.001 },
    'free sulfur dioxide': { min: 1.0, max: 72.0, step: 1 },
    'total sulfur dioxide': { min: 6.0, max: 289.0, step: 1 },
    'density': { min: 0.99007, max: 1.00369, step: 0.00001 },
    'pH': { min: 2.74, max: 4.01, step: 0.01 },
    'sulphates': { min: 0.33, max: 2.00, step: 0.01 },
    'alcohol': { min: 8.4, max: 14.9, step: 0.1 },
};


const WineClassifier: React.FC = () => {
    const [wineData, setWineData] = useState(initialWineState);
    const [prediction, setPrediction] = useState<'good' | 'bad' | null>(null);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setWineData(prevData => ({
            ...prevData,
            [name]: parseFloat(value)
        }));
        setPrediction(null); // Reset prediction on new input
    };

    const handleClassify = () => {
        // Modelo de predicción simulado y simplificado
        // Basado en las correlaciones observadas: alcohol es bueno, acidez volátil es mala.
        const alcoholScore = (wineData.alcohol - 10.4); // Centrado en la media
        const acidityScore = (wineData['volatile acidity'] - 0.52); // Centrado en la media

        // Damos más peso a la acidez volátil por su impacto negativo
        const finalScore = alcoholScore - acidityScore * 2;

        if (finalScore > 0.3) {
            setPrediction('good');
        } else {
            setPrediction('bad');
        }
    };

    const formatLabel = (key: string) => {
        return key.charAt(0).toUpperCase() + key.slice(1);
    }
    
    const getPrecision = (step: number) => {
        if (Math.floor(step) === step) return 0;
        const parts = step.toString().split(".");
        return parts[1] ? parts[1].length : 0;
    }

    return (
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-4 text-center">Clasificador de Calidad de Vino Interactivo</h3>
            <p className="text-sm text-center text-slate-600 mb-6">Mueve los controles deslizantes para ajustar los parámetros y luego haz clic en "Clasificar Vino" para ver la predicción.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 mb-8">
                {Object.keys(wineData).map(key => {
                    const featureKey = key as WineFeatures;
                    const config = featureConfig[featureKey];
                    const precision = getPrecision(config.step);

                    return (
                        <div key={featureKey}>
                            <div className="flex justify-between items-center mb-1">
                                <label htmlFor={featureKey} className="block text-sm font-medium text-slate-700 capitalize">
                                    {formatLabel(featureKey)}
                                </label>
                                <span className="text-sm font-semibold text-indigo-600 bg-indigo-100 px-2 py-0.5 rounded-md tabular-nums">
                                    {wineData[featureKey].toFixed(precision)}
                                </span>
                            </div>
                            <input
                                type="range"
                                id={featureKey}
                                name={featureKey}
                                min={config.min}
                                max={config.max}
                                step={config.step}
                                value={wineData[featureKey]}
                                onChange={handleInputChange}
                                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-red-700"
                            />
                        </div>
                    );
                })}
            </div>

            <div className="text-center">
                <button
                    onClick={handleClassify}
                    className="inline-flex items-center px-6 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-red-700 hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                    Clasificar Vino
                </button>
            </div>

            {prediction && (
                <div className={`mt-6 p-4 rounded-lg text-center transition-all duration-300 ${prediction === 'good' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    <p className="font-bold text-lg">
                        Predicción del Modelo: {prediction === 'good' ? 'Vino de Buena Calidad' : 'Vino de Calidad Regular'}
                    </p>
                </div>
            )}
        </div>
    );
};

export default WineClassifier;
