import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { HistogramData } from '../../types';

const HousingHistogram: React.FC = () => {
    const data: HistogramData[] = [
        { name: '0-1', value: 350 },
        { name: '1-2', value: 1800 },
        { name: '2-3', value: 1400 },
        { name: '3-4', value: 1100 },
        { name: '4-5', value: 950 },
        { name: '5+', value: 500 },
    ];
    
    return (
        <div className="w-full h-[300px]">
            <h3 className="text-center font-bold text-slate-700 mb-4">Distribución (Histograma Simulado)</h3>
            <ResponsiveContainer>
                <BarChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" label={{ value: 'Valor de la Característica', position: 'insideBottom', offset: -5 }} />
                    <YAxis label={{ value: 'Frecuencia', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" name="Frecuencia" fill="#8884d8" />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default HousingHistogram;