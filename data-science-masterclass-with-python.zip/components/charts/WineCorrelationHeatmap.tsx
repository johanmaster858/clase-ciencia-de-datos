
import React from 'react';
import type { CorrelationMatrix } from '../../types';

const WineCorrelationHeatmap: React.FC = () => {
  // Datos de correlación simulados, basados en valores típicos del dataset de vino tinto
  const data: CorrelationMatrix = {
    labels: ['quality', 'alcohol', 'sulphates', 'citric acid', 'volatile acidity'],
    values: [
      [1.00, 0.48, 0.25, 0.23, -0.39],
      [0.48, 1.00, 0.09, 0.11, -0.20],
      [0.25, 0.09, 1.00, 0.31, -0.26],
      [0.23, 0.11, 0.31, 1.00, -0.55],
      [-0.39, -0.20, -0.26, -0.55, 1.00]
    ]
  };

  const getColor = (value: number) => {
    // Escala de colores Rojo-Blanco-Azul (divergente)
    if (value > 0.4) return 'bg-red-600';
    if (value > 0.2) return 'bg-red-400';
    if (value < -0.4) return 'bg-blue-600';
    if (value < -0.2) return 'bg-blue-400';
    return 'bg-slate-200 text-slate-800'; // Cerca de cero
  };

  return (
    <div className="flex flex-col items-center">
        <h3 className="text-center font-bold text-slate-700 mb-4">Matriz de Correlación del Vino (Simulada)</h3>
        <div className="grid grid-cols-6 gap-1 p-2">
            {/* Header row */}
            <div />
            {data.labels.map(label => (
                <div key={label} className="font-bold text-xs text-center p-1 break-words">{label}</div>
            ))}

            {/* Data rows */}
            {data.values.map((row, rowIndex) => (
                <React.Fragment key={rowIndex}>
                    <div className="font-bold text-xs flex items-center justify-end p-1 break-words">{data.labels[rowIndex]}</div>
                    {row.map((value, colIndex) => (
                        <div key={`${rowIndex}-${colIndex}`} className={`flex items-center justify-center text-white font-mono text-xs p-2 rounded ${getColor(value)}`}>
                            {value.toFixed(2)}
                        </div>
                    ))}
                </React.Fragment>
            ))}
        </div>
    </div>
  );
};

export default WineCorrelationHeatmap;
