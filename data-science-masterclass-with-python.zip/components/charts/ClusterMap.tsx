import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import type { ClusterData } from '../../types';

const ClusterMap: React.FC = () => {
    const colors = ['#ffc658', '#82ca9d', '#8884d8', '#ff8042', '#00C49F', '#FFBB28'];

    const generateCluster = (cx: number, cy: number, numPoints: number, clusterId: number) => {
        return Array.from({ length: numPoints }, () => ({
            x: cx + (Math.random() - 0.5) * 1.5,
            y: cy + (Math.random() - 0.5) * 1.5,
            cluster: clusterId,
        }));
    };
    
    const data: ClusterData[] = [
        ...generateCluster(-122.4, 37.7, 40, 0), // SF Bay Area
        ...generateCluster(-118.2, 34.0, 50, 1), // LA
        ...generateCluster(-121.9, 36.6, 20, 2), // Monterey
        ...generateCluster(-117.1, 32.7, 30, 3), // San Diego
        ...generateCluster(-121.5, 38.5, 25, 4), // Sacramento
        ...generateCluster(-119.8, 36.7, 15, 5), // Fresno
    ];

    return (
        <div className="w-full h-[400px]">
             <h3 className="text-center font-bold text-slate-700 mb-4">Clusters de Vecindarios en California (Simulado)</h3>
            <ResponsiveContainer>
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                    <CartesianGrid />
                    <XAxis type="number" dataKey="x" name="Longitud" domain={[-125, -114]}/>
                    <YAxis type="number" dataKey="y" name="Latitud" domain={[32, 42]}/>
                    <Tooltip cursor={{ strokeDasharray: '3 3' }}/>
                    {Array.from({length: 6}, (_, i) => (
                         <Scatter key={`cluster-${i}`} name={`Cluster ${i}`} data={data.filter(d => d.cluster === i)} fill={colors[i]} shape="circle" />
                    ))}
                </ScatterChart>
            </ResponsiveContainer>
        </div>
    );
};

export default ClusterMap;