import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { ScatterDataWithColor } from '../../types';

const IncomeScatterPlot: React.FC = () => {
    const data: ScatterDataWithColor[] = Array.from({ length: 150 }, (_, i) => {
        const x = Math.random() * 8 + 1;
        const y = x * 0.4 + Math.random() * 2 - 1 + (x / 10);
        return { x, y: Math.min(5, Math.max(0.5, y)), z: y * 100 };
    });

    return (
        <div className="w-full h-[350px]">
            <h3 className="text-center font-bold text-slate-700 mb-4">Precio Vivienda vs. Ingreso Medio (Simulado)</h3>
            <ResponsiveContainer>
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                    <CartesianGrid />
                    <XAxis type="number" dataKey="x" name="Ingreso Medio" unit="0k" />
                    <YAxis type="number" dataKey="y" name="Valor Vivienda" unit="00k" />
                    <ZAxis type="number" dataKey="z" range={[50, 500]} name="Precio" unit="$" />
                    <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                    <Legend />
                    <Scatter name="Viviendas" data={data} fill="#8884d8" shape="circle" />
                </ScatterChart>
            </ResponsiveContainer>
        </div>
    );
};

export default IncomeScatterPlot;