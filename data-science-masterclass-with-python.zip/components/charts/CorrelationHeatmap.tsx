
import React from 'react';
import type { CorrelationMatrix } from '../../types';

const CorrelationHeatmap: React.FC = () => {
  const data: CorrelationMatrix = {
    labels: ['MedHouseVal', 'MedInc', 'HouseAge', 'AveRooms'],
    values: [
      [1.00, 0.69, 0.11, 0.15],
      [0.69, 1.00, -0.12, 0.33],
      [0.11, -0.12, 1.00, -0.15],
      [0.15, 0.33, -0.15, 1.00]
    ]
  };

  const getColor = (value: number) => {
    if (value > 0.5) return 'bg-red-500';
    if (value > 0.2) return 'bg-red-300';
    if (value > -0.2) return 'bg-blue-100';
    return 'bg-blue-300';
  };

  return (
    <div className="flex flex-col items-center">
        <h3 className="text-center font-bold text-slate-700 mb-4">Matriz de Correlación (Simulada)</h3>
        <div className="grid grid-cols-5 gap-1">
            {/* Header row */}
            <div />
            {data.labels.map(label => (
                <div key={label} className="font-bold text-xs text-center p-1">{label}</div>
            ))}

            {/* Data rows */}
            {data.values.map((row, rowIndex) => (
                <React.Fragment key={rowIndex}>
                    <div className="font-bold text-xs flex items-center justify-end p-1">{data.labels[rowIndex]}</div>
                    {row.map((value, colIndex) => (
                        <div key={`${rowIndex}-${colIndex}`} className={`flex items-center justify-center text-white font-mono text-xs p-2 rounded ${getColor(value)}`}>
                            {value.toFixed(2)}
                        </div>
                    ))}
                </React.Fragment>
            ))}
        </div>
    </div>
  );
};

export default CorrelationHeatmap;
