
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { HistogramData } from '../../types';

const WineQualityHistogram: React.FC = () => {
    // Datos simulados que representan la distribución típica de la calidad del vino tinto
    const data: HistogramData[] = [
        { name: '3', value: 10 },
        { name: '4', value: 53 },
        { name: '5', value: 681 },
        { name: '6', value: 638 },
        { name: '7', value: 199 },
        { name: '8', value: 18 },
    ];
    
    return (
        <div className="w-full h-[300px]">
            <h3 className="text-center font-bold text-slate-700 mb-4">Distribución de Calidad del Vino (Simulada)</h3>
            <ResponsiveContainer>
                <BarChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" label={{ value: 'Puntuación de Calidad', position: 'insideBottom', offset: -5 }} />
                    <YAxis label={{ value: 'Frecuencia', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" name="Número de Vinos" fill="#A40E4C" />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default WineQualityHistogram;
