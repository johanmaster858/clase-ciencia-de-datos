
import React from 'react';

const LightBulbIcon: React.FC<{className?: string}> = ({ className = "h-6 w-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.311a7.5 7.5 0 01-7.5 0c-1.421-.632-2.672-1.943-3.48-3.675A11.953 11.953 0 016 6a6 6 0 0112 0c0 3.058-1.478 5.758-3.75 7.478z" />
    </svg>
);


const AnalysisBlock: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="my-6 p-4 bg-amber-50 border-l-4 border-amber-400 text-amber-900 rounded-r-lg">
      <div className="flex items-start">
        <div className="flex-shrink-0">
            <LightBulbIcon className="h-5 w-5 text-amber-500" />
        </div>
        <div className="ml-3">
          <p className="text-sm font-semibold">Análisis:</p>
          <p className="mt-1 text-sm">{children}</p>
        </div>
      </div>
    </div>
  );
};

export default AnalysisBlock;
