
import React from 'react';

interface SectionCardProps {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

const SectionCard: React.FC<SectionCardProps> = ({ title, subtitle, children }) => {
  return (
    <section className="bg-white shadow-lg rounded-xl p-6 md:p-8 my-8 ring-1 ring-slate-900/5">
      <h2 className="text-3xl font-bold text-slate-900 tracking-tight">{title}</h2>
      {subtitle && <p className="text-lg text-indigo-600 mt-1 mb-6 font-medium">{subtitle}</p>}
      <div className="mt-6 text-slate-600 text-base leading-7">
        {children}
      </div>
    </section>
  );
};

export default SectionCard;
